package com.example.kuis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView tvpertanyaan;
    RadioGroup rg;
    RadioButton rbjawaban1,rbjawaban2,rbjawaban3,rbjawaban4,rbjawaban5;
    Button btlanjur;
    String pertanyaan[]={"1.  Subselection tool digunakan untuk…. ",
            "2. Shortcut Ctrl+B merupakan shortcut yang kita gunakan untuk…. ",
            "3. Shortcut yang digunakan untuk command Paste in Place adalah: ",
            "4. Free Transform tool digunakan untuk : ",
            "5. Objek(teks atau gambar) yang bergerak disebut……. ",
            "6. Option untuk menampilkan text pada marcromedia flash adalah",
            "7. Sebuah gambar yang tersusun oleh garis dan grafik adalah ",
            "8. Membuat animasi berubah bentuk menggunakan… ",
            "9. Untuk menggerakkan objek sesuai jalur yang diinginkan dengan menggunakan suatu garis yang memandu menggunakan… ",
            "10. Untuk memberi warna pada garis tepi menggunakan… ",
            "11. Tool yang digunakan untuk memberi aksi pada sebuah objek adalah...",
            "12. Jika kita mau mewarnai sebuah garis, maka menggunakan tool…",
            "13. Maksud dari 20 fps adalah..",
            "14. Alat ynag digunakan untuk melakukan editing pada menu flash adalah..",
            "15. Shortcut yang digunakan untuk “insert keyframe.."};
    String jawaban[]={"Mengubah bentuk melalui titik-titik pada pinggiran objek","Mengubah warna objek","Mengubah jenis frame pada sebuah layer","Mengubah warna stage","Membuka properties pada sebuah  objek",
            "Melakukan perintah paste pada objek yang telah dikopi","Melakukan konversi objek","Mengubah warna stage","Mengubah bentuk objek","Membuat tulisan (text tool)",
            "F6","F9","Ctrl + V","Ctrl + Shift + V","Ctrl + C",
            "Memasukkan Text","Membuat obyek berbentuk persegi","Mengubah bentuk obyek","Memberi warna","Membuat Garis",
            "Animasi","Guide","Motion","Shape","Action",
            "Pencil Tool","Pen tool","Erase Tool","Text Tool","Brush Tool",
            "Vector","Bitmap","SVG","PNG","JPEG",
            "Motion Tool","Motion Shape","Motion Guide","Motion Tween","Motion Classic",
            "Motion Tool","Motion Shape","Motion Guide","Motion Tween","Motion Classic",
            "Hand Tool","Eyedropper Tool","Stroke Color","Fill color","Paint bucket tool",
            "Action","Link","Aksi","Motion","Kodingan",
            "Interactive Transparency Tool","Eyedropper Tool"," Inline Tool","FreeHand Tool","Outline Tool",
            "ada 25 frame dalam satu waktu","ada 20 frame dalam satu jam","ada 21 frame dalam satu detik","ada 20 frame dalam satu detik","ada 11 frame dalam satu menit",
            "Tool","Objek","Motion","Line","Outine",
            "Ctrl + k","F6","F5","F7","Shift i"};

    String jawaban_benar[]={"Mengubah bentuk melalui titik-titik pada pinggiran objek",
            "Melakukan konversi objek",
            "Ctrl + Shift + V",
            "Mengubah bentuk obyek",
            "Animasi",
            "Text Tool",
            "Vector",
            "Motion Shape",
            "Motion Guide",
            "Stroke Color",
            "Action",
            "Outline Tool",
            "ada 20 frame dalam satu detik",
            "Tool",
            "F6"};
    int naik=0;
    int benar=0,salah=0;
    int hasil=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvpertanyaan=findViewById(R.id.pertanyaan);
        getSupportActionBar().setTitle("QUIZ");
        rg=findViewById(R.id.group);
        rbjawaban1=findViewById(R.id.jawaban1);
        rbjawaban2=findViewById(R.id.jawaban2);
        rbjawaban3=findViewById(R.id.jawaban3);
        rbjawaban4=findViewById(R.id.jawaban4);
        rbjawaban5=findViewById(R.id.jawaban5);
        btlanjur=findViewById(R.id.lanjut);
        btlanjur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanjut();
            }
        });
        tvpertanyaan.setText(pertanyaan[0]);
        rbjawaban1.setText(jawaban[0]);
        rbjawaban2.setText(jawaban[1]);
        rbjawaban3.setText(jawaban[2]);
        rbjawaban4.setText(jawaban[3]);
        rbjawaban5.setText(jawaban[4]);
    }
    public void lanjut(){
        if (rbjawaban1.isChecked()||rbjawaban2.isChecked()||rbjawaban3.isChecked()||rbjawaban4.isChecked()||rbjawaban5.isChecked()){

            RadioButton jawaban_pilih=findViewById(rg.getCheckedRadioButtonId());
            String jawaban_user=jawaban_pilih.getText().toString();
            for(int i=0;i<pertanyaan.length;i++) {
                if (jawaban_user.equals(jawaban_benar[i])) {
                    benar++;
                }else{
                    salah++;
                }
            }
            naik++;
            if (naik<pertanyaan.length){
                rg.clearCheck();
                tvpertanyaan.setText(pertanyaan[naik]);
                rbjawaban1.setText(jawaban[(naik*5)+0]);
                rbjawaban2.setText(jawaban[(naik*5)+1]);
                rbjawaban3.setText(jawaban[(naik*5)+2]);
                rbjawaban4.setText(jawaban[(naik*5)+3]);
                rbjawaban5.setText(jawaban[(naik*5)+4]);


            }else {
                hasil=(benar*6)+10;
                Intent i=new Intent(MainActivity.this,Hasil.class);
                i.putExtra("hasil",hasil);
                i.putExtra("benar",benar);
                startActivity(i);
            }
        }else {
            Toast.makeText(this, "Silahkan Pilih Jawaban", Toast.LENGTH_SHORT).show();
        }
    }
}
