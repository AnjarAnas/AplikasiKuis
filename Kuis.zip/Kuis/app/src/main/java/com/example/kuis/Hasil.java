package com.example.kuis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Hasil extends AppCompatActivity {
    TextView tvhasil,tvbenar,tvket;
    Button btulang;
    int hasil,benar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);
        getSupportActionBar().setTitle("Hasil");
        tvhasil=findViewById(R.id.hasil);
        btulang=findViewById(R.id.ulang);
        tvket=findViewById(R.id.keterangan);
        tvbenar=findViewById(R.id.benar);
        btulang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Hasil.this,MainActivity.class);
                startActivity(intent);
            }
        });
        benar=getIntent().getIntExtra("benar",0);
        hasil=getIntent().getIntExtra("hasil",0);
        if (hasil>=95){
            tvket.setText("Pertahankan Ya");
        }else if(hasil>=80){
            tvket.setText("Bagus Tingkatkan Terus Ya..");
        }else if (hasil>=75){
            tvket.setText("Jangan Lupa Belajar Ya");
        }else if (hasil>=60){
            tvket.setText("Jangan Menyerah");
        }else {
            tvket.setText("Jnagan Kebanyakan Main");
        }
        tvbenar.setText("Jawab Benar Anda: "+benar);
        tvhasil.setText(""+hasil);
    }
}
